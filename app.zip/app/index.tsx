import SplashScreen from "@/src/layouts/SplashScreen";
export default function Index(){
  return <SplashScreen/>
}
